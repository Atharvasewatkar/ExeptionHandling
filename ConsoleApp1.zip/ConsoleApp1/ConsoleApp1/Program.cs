﻿using ConsoleApp1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExeptionHandling

{
    internal class Program
    {
        static void Main(string[] args)
        {
            //1>.IndexOutOfRangeException: 
            // Exaptions.exp1();

            //2>System.DivideByZeroException
            // Exaptions.exp2();

            //NullReferenceException: 
            Exaptions.exp3();


            
        }
    }
}
